package com.example.appcadprod_testes

enum class Categoria{
    Mobile, Computadores, Bags
}