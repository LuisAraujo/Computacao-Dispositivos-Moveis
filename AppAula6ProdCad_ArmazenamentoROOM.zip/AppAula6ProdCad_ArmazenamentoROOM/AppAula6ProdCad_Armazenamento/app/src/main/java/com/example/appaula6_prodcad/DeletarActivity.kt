package com.example.appaula6_prodcad

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.ViewGroup
import android.widget.*

class DeletarActivity: AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_deletar)

        setTitle("Deletar Produtos");

        //PASSOS
        //1 - você deve criar um input da tela de delete para digitar o nome
        //2 - você deve criar um botão buscar
        //3 - ao clicar deve-se buscar no Banco (veja exemplo em Listar)
        //4 - Caso exista produtos, deve listá-lós
        //5 - nesta lista deve ao clicar no item ele deve ser deletado
            //você pode criar outra lógica, com um checkbox ou um botão


        val linearLayout = findViewById<LinearLayout>(R.id.deletarlayout)

        // Create Checkbox Dynamically
        val checkBox = CheckBox(this)
        checkBox.setText("titulo")
        checkBox.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        checkBox.setOnCheckedChangeListener { buttonView, isChecked ->
            val msg = "You have " + (if (isChecked) "checked" else "unchecked") + " this Check it Checkbox."
            Toast.makeText(this@DeletarActivity, msg, Toast.LENGTH_SHORT).show()
        }

        // Add Checkbox to LinearLayout
        linearLayout?.addView(checkBox)


        /* EXEMPLO de Toque no Item
        listView.setOnItemClickListener(){adapterView, view, position, id ->
            val itemAtPos = adapterView.getItemAtPosition(position)
            val itemIdAtPos = adapterView.getItemIdAtPosition(position)
            Toast.makeText(this, "Click on item at $itemAtPos its item id $itemIdAtPos", Toast.LENGTH_LONG).show()
        }*/
    }
}