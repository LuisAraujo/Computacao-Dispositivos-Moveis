package com.example.appaula6_prodcad

import android.content.Context

object  App{

    lateinit private var ctx: Context

    fun setContext(context: Context){
        this.ctx = context;
    }

    fun getContext() : Context{
        return  this.ctx;
    }
}