package com.example.appaula6_prodcad

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.Toast

class ListarActivity: AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_listar)
        setTitle("Listar Produtos")



        //var arrTest = arrayListOf<String>("T1", "T2", "T3")
        var listView = findViewById(R.id.listview) as ListView
        var produtos: List<Produto> = BancoDadosGerenciador.getProdutoDAO().findAll()
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, produtos)
        listView.adapter = adapter


        

    }
}