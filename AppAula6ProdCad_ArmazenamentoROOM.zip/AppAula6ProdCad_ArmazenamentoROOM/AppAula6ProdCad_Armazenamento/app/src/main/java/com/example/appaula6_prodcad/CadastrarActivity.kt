package com.example.appaula6_prodcad

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner

class CadastrarActivity: AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastra)
        setTitle("Cadastrar Produto")

        var app: App = App

        var btCadastrar = findViewById(R.id.btcad) as Button
        var inpNome = findViewById(R.id.inpnome) as EditText
        var inpPreco = findViewById(R.id.inppreco) as EditText
        var inpDesc = findViewById(R.id.inpdesc) as EditText
        var inpCat = findViewById(R.id.inpcat) as Spinner

        //array de categorias
        var arrayCat: ArrayList<Categoria> = arrayListOf(
            Categoria.Bags, Categoria.Computadores, Categoria.Mobile
        )

        val adaptador = ArrayAdapter<Categoria>(
            this, android.R.layout.simple_spinner_item,
            arrayCat
        )

        adaptador.setDropDownViewResource(
            android.R.layout.simple_dropdown_item_1line
        )

        inpCat.adapter = adaptador

        btCadastrar.setOnClickListener{

            var p = Produto(
                id = 0,
                nome = inpNome.text.toString(),
                preco = inpPreco.text.toString().toDouble(),
                descricao = inpDesc.toString()
                //categoria = (inpCat.getSelectedItem() as Categoria).number
            )

            BancoDadosGerenciador.getProdutoDAO().insert(p)

            var b = AlertDialog.Builder(this)
            b.setTitle("ok")
            b.setMessage("Produto Cadastrado com Sucesso")
            b.show();
        }


    }
}
