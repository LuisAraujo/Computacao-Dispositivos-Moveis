package com.example.appaula6_prodcad

import android.arch.persistence.room.Database
import android.arch.persistence.room.RoomDatabase

@Database(entities = [Produto::class], version = 1)
abstract class ProdutoDatabase: RoomDatabase(){
    abstract fun ProdutoDAO(): ProdutoDAO
}
