package com.example.appaula6_prodcad

import android.arch.persistence.room.Dao
import android.arch.persistence.room.Delete
import android.arch.persistence.room.Insert
import android.arch.persistence.room.Query
@Dao
interface ProdutoDAO {

    @Insert
    public fun insert(produto: Produto)

    @Delete
    fun delete(produto: Produto)

    @Query("SELECT * FROM produto where id = :id")
    fun getById(id: Int): Produto?

    @Query("SELECT * FROM produto")
    fun findAll(): List<Produto>
}