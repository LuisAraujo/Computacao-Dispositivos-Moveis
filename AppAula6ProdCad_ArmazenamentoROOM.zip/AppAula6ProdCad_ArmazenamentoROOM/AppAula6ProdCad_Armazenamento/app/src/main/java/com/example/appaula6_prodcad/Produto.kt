package com.example.appaula6_prodcad
import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey

@Entity
class Produto(
    @PrimaryKey(autoGenerate = true)
    protected var id: Int,
    protected  var nome: String,
    protected  var preco: Double,
   // protected  var categoria: Int,
    protected  var descricao: String){


    override fun toString(): String{
        return this.nome
    }

}


