package com.example.appaula6_prodcad

import android.arch.persistence.room.Room
import android.content.Context

object BancoDadosGerenciador {

    lateinit private var bdInstancia: ProdutoDatabase
    lateinit var ctx: Context

    init {

        bdInstancia = Room.databaseBuilder(
            App.getContext(),
            ProdutoDatabase::class.java,
            "produtosqlite"
        ).allowMainThreadQueries().build()
    }

    fun getProdutoDAO(): ProdutoDAO {
        return bdInstancia.ProdutoDAO()
    }

}