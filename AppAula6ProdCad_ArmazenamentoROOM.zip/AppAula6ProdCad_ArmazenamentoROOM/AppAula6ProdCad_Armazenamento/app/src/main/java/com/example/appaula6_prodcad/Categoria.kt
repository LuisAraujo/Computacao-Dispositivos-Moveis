package com.example.appaula6_prodcad

enum class Categoria(val number: Int){
    Mobile(0), Computadores(1), Bags(2)
}